import { Locator, expect, test, type Page } from "playwright/test"
import { useTable } from './table'
import { formatDateTime } from "../helpers/format"

export interface Topic {
    name: string
    summary: string
    lastMessage: string
    messages: string
}

export function useKafkaTopics(table: Locator) {
    const topics = useTable(table, ['Name', 'Summary', 'Last Message', 'Messages'])
    return {
        async testTopic(row: number, topic: Topic) {
            await test.step(`Check Kafka topic in row ${row}`, async () => {
                const t = topics.getRow(row + 1)
                await expect(t.getCellByName('Name')).toHaveText(topic.name)
                await expect(t.getCellByName('Summary')).toHaveText(topic.summary)
                await expect(t.getCellByName('Last Message')).toHaveText(topic.lastMessage)
                await expect(t.getCellByName('Messages')).toHaveText(topic.messages)
            })
        }
    }
}

export interface Group {
    name: string
    state: string
    protocol: string
    generation: string
    lastRebalancing: string
    members: number
}

export function useKafkaGroups(table: Locator, topic?: string) {
    return {
        async testGroup(row: number, group: Group, lags?: string) {
            await test.step(`Check Kafka group in row ${row}`, async () => {
                let columns = ['Name', 'State', 'Protocol', 'Generation', 'Last Rebalancing', 'Members']
                if (lags) {
                    columns.push('Lag')
                }
                const groups = useTable(table, columns)

                const g = groups.getRow(row + 1)
                await expect(g.getCellByName('Name')).toHaveText(group.name)
                await expect(g.getCellByName('State')).toHaveText(group.state)
                await expect(g.getCellByName('Protocol')).toHaveText(group.protocol)
                if (lags) {
                    await expect(g.getCellByName('Lag')).toHaveText(lags)
                }
            })
        }
    }
}

export interface Partition {
    id: string
    startOffset: string
    offset: string
    segments: string
}

export function useKafkaPartitions(table: Locator) {
    const partitions = useTable(table, ['ID', 'Start Offset', 'Offset', 'Segments'])
    return {
        async testPartition(row: number, partition: Partition) {
            await test.step(`Check Kafka partition in row ${row}`, async () => {
                const p = partitions.getRow(row + 1)
                await expect(p.getCellByName('ID')).toHaveText(partition.id)
                await expect(p.getCellByName('Start Offset')).toHaveText(partition.startOffset)
                await expect(p.getCellByName('Offset')).toHaveText(partition.offset)
                await expect(p.getCellByName('Segments')).toHaveText(partition.segments)
            })
        }
    }
}

export function useKafkaMessages(page: Page) {
    return {
        test: async (table: Locator, withTopic: boolean = true) => {
            await test.step('Check messages log', async () => {
                let columns = ['Topic', 'Key', 'Value', 'Time']
                if (!withTopic) {
                    columns.splice(0,1)
                }

                const messages = await useTable(table, columns)
                let message = messages.getRow(1)
                await expect(message.getCellByName('Key')).toHaveText('GGOEWXXX0827')
                await expect(message.getCellByName('Value')).toHaveText(/^{"id":"GGOEWXXX0827","name":"Waze Women's Short Sleeve Tee",/)
                if (withTopic) {
                    await expect(message.getCellByName('Topic')).toHaveText('mokapi.shop.products')
                }
                await expect(message.getCellByName('Time')).toHaveText(formatDateTime('2023-02-13T09:49:25.482366+01:00'))

                await message.click()
                await expect(page.getByLabel('Kafka Key', { exact: true })).toHaveText('GGOEWXXX0827')
                await expect(page.getByLabel('Kafka Topic', { exact: true })).toHaveText('mokapi.shop.products')
                await expect(page.getByLabel('Service Type', { exact: true })).toHaveText('KAFKA')
                await expect(page.getByLabel('Offset', { exact: true })).toHaveText('0')
                await expect(page.getByLabel('Partition', { exact: true })).toHaveText('0')
                await expect(page.getByText('Producer Id', { exact: true })).not.toBeVisible({ timeout: 100 })
                await expect(page.getByText('Producer Epoch', { exact: true })).not.toBeVisible({ timeout: 100 })
                await expect(page.getByText('Sequence Number', { exact: true })).not.toBeVisible({ timeout: 100 })
                await expect(page.getByRole('region', { name: 'Meta' }).getByLabel('Content Type', { exact: true })).toHaveText('application/json')
                await expect(page.getByLabel('Key Type', { exact: true })).toHaveText('string')
                await expect(page.getByLabel('Time', { exact: true })).toHaveText(formatDateTime('2023-02-13T09:49:25.482366+01:00'))

                await page.goBack()
        
                message = messages.getRow(2)
                await expect(message.getCellByName('Key')).toHaveText('GGOEWXXX0828')
                await expect(message.getCellByName('Value')).toHaveText(/^{"id":"GGOEWXXX0828","name":"Waze Men's Short Sleeve Tee",/)
                if (withTopic) {
                    await expect(message.getCellByName('Topic')).toHaveText('mokapi.shop.products')
                }
                await expect(message.getCellByName('Time')).toHaveText(formatDateTime('2023-02-13T09:49:25.482366+01:00'))

                await message.click()
                await expect(page.getByLabel('Kafka Key', { exact: true })).toHaveText('GGOEWXXX0828')
                await expect(page.getByLabel('Kafka Topic', { exact: true })).toHaveText('mokapi.shop.products')
                await expect(page.getByLabel('Service Type', { exact: true })).toHaveText('KAFKA')
                await expect(page.getByLabel('Offset', { exact: true })).toHaveText('1')
                await expect(page.getByLabel('Partition', { exact: true })).toHaveText('1')
                await expect(page.getByLabel('Producer Id', { exact: true })).toHaveText('3')
                await expect(page.getByLabel('Producer Epoch', { exact: true })).toHaveText('1')
                await expect(page.getByLabel('Sequence Number', { exact: true })).toHaveText('1')
                await expect(page.getByRole('region', { name: 'Meta' }).getByLabel('Content Type', { exact: true })).toHaveText('application/json')
                await expect(page.getByLabel('Key Type', { exact: true })).toHaveText('string')
                await expect(page.getByLabel('Time', { exact: true })).toHaveText(formatDateTime('2023-02-13T09:49:25.482366+01:00'))

                await page.goBack()
            })
        }
    }
}